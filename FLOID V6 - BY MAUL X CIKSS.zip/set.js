module.exports = {
    ChannelUsername: "@rainonetime",
    githubToken: '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',
    githubRepo: 'ZephyrineNasution/databasex',
    ownerId: '7308812889',
    githubResellerFilePath: 'resellers.json',
    githubFilePath: 'trashissue.json'
};

