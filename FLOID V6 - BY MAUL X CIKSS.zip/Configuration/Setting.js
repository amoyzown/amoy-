/*
         Created by Zephyrine 
        Telegram : @rainoneday
   All Right Reversed By Zephyrine
*/

module.exports = {
    TokenS: "7791207400:AAENetXdcTJugy7WX50HBSxoq_qkFlpDGwM",
    admins: ["7192039266"]
};